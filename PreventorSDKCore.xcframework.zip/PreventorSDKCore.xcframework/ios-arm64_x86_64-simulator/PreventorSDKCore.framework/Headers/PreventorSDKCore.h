//
//  PreventorSDKCore.h
//  PreventorSDKCore
//
//  Created by Alexander Rodriguez on 18/02/22.
//

#import <Foundation/Foundation.h>

//! Project version number for PreventorSDKCore.
FOUNDATION_EXPORT double PreventorSDKCoreVersionNumber;

//! Project version string for PreventorSDKCore.
FOUNDATION_EXPORT const unsigned char PreventorSDKCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PreventorSDKCore/PublicHeader.h>


